export interface StockDetails{
    qty:number;
    stockname:string;
    price:number;
    ltp:number;
}