export interface WorkPackage{
    workpackageId :String;
    cspInvoiceNumber :String;
    vendorName:String;
    programNm:String;
    workpackageApplicationNm:String;
    modifiedFileInd:String;
    workpackageStatus:String;
    jobId:string;
    serviceFirstName:string;
    serviceLastName:String;

}