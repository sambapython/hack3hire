export interface District{
    companyId :String;
    districtId :String;
    districtName:String;
    info1:String;
    info2:String;
}